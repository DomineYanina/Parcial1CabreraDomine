package ar.edu.unlam.pb2.pokeParcial;

public class PokemonCuracion extends Pokemon { //faltan metodos de ataques

	
	private Integer ataqueTeCuro = 50;

public PokemonCuracion(String nombre) {
	super(nombre);
}


	
	
}
