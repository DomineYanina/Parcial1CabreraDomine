package ar.edu.unlam.pb2.pokeParcial;

	import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
	import java.util.Random;

	public class Batalla { //me falto la clase de Pokemon curacion y Pokemon potenciador 
	    private static final String[] POKENOMBRES = {"Squirtle", "Wartortle", "Blastoise", "Psyduck", "Golduck", "Poliwag", "Poliwhirl", "Poliwrath", "Tentacool", "Tentacruel", "Slowpoke", "Slowbro", "Seel", "Dewgong", "Shellder", "Cloyster", "Krabby", "Kingler", "Horsea", "Seadra", "Goldeen", "Seaking", "Staryu", "Starmie", "Magikarp", "Gyarados", "Lapras", "Vaporeon", "Omanyte", "Omastar", "Kabuto", "Kabutops", "Totodile", "Croconaw", "Feraligatr", "Chinchou", "Lanturn", "Marill", "Azumarill", "Politoed", "Wooper", "Quagsire", "Slowking", "Qwilfish", "Corsola", "Remoraid", "Octillery", "Mantine", "Kingdra", "Suicune", "Charmander", "Charmeleon", "Charizard", "Vulpix", "Ninetales", "Growlithe", "Arcanine", "Ponyta", "Rapidash", "Magmar", "Flareon", "Moltres", "Cyndaquil", "Quilava", "Typhlosion", "Slugma", "Magcargo", "Houndour", "Houndoom", "Entei", "Pikachu", "Raichu", "Magnemite", "Magneton", "Voltorb", "Electrode", "Electabuzz", "Jolteon", "Zapdos", "Chinchou", "Lanturn", "Pichu", "Mareep", "Flaaffy", "Ampharos", "Elekid", "Raikou", "Bulbasaur", "Ivysaur", "Venusaur", "Oddish", "Gloom", "Vileplume", "Paras", "Parasect", "Bellsprout", "Weepinbell", "Victreebel", "Exeggcute", "Exeggutor", "Tangela", "Chikorita", "Bayleef", "Meganium", "Bellossom", "Hoppip", "Skiploom", "Jumpluff", "Sunkern", "Sunflora", "Celebi"};
	    private static final String[] NOMBRES_POKEMON_AGUA = {"Squirtle", "Wartortle", "Blastoise", "Psyduck", "Golduck", "Poliwag", "Poliwhirl", "Poliwrath", "Tentacool", "Tentacruel", "Slowpoke", "Slowbro", "Seel", "Dewgong", "Shellder", "Cloyster", "Krabby", "Kingler", "Horsea", "Seadra", "Goldeen", "Seaking", "Staryu", "Starmie", "Magikarp", "Gyarados", "Lapras", "Vaporeon", "Omanyte", "Omastar", "Kabuto", "Kabutops", "Totodile", "Croconaw", "Feraligatr", "Chinchou", "Lanturn", "Marill", "Azumarill", "Politoed", "Wooper", "Quagsire", "Slowking", "Qwilfish", "Corsola", "Remoraid", "Octillery", "Mantine", "Kingdra", "Suicune"};
	    private static final String[] NOMBRES_POKEMON_FUEGO = {"Charmander", "Charmeleon", "Charizard", "Vulpix", "Ninetales", "Growlithe", "Arcanine", "Ponyta", "Rapidash", "Magmar", "Flareon", "Moltres", "Cyndaquil", "Quilava", "Typhlosion", "Slugma", "Magcargo", "Houndour", "Houndoom", "Entei"};
	    private static final String[] NOMBRES_POKEMON_ELECTRICOS  = {"Pikachu", "Raichu", "Magnemite", "Magneton", "Voltorb", "Electrode", "Electabuzz", "Jolteon", "Zapdos", "Chinchou", "Lanturn", "Pichu", "Mareep", "Flaaffy", "Ampharos", "Elekid", "Raikou"};
	    private static final String[] NOMBRES_POKEMON_PLANTA = {"Bulbasaur", "Ivysaur", "Venusaur", "Oddish", "Gloom", "Vileplume", "Paras", "Parasect", "Bellsprout", "Weepinbell", "Victreebel", "Exeggcute", "Exeggutor", "Tangela", "Chikorita", "Bayleef", "Meganium", "Bellossom", "Hoppip", "Skiploom", "Jumpluff", "Sunkern", "Sunflora", "Celebi"};
	    
	    
	    List<Pokemon> pokemonListJugadorUno = new ArrayList<Pokemon>();
	    List<Pokemon> pokemonListJugadorDos = new ArrayList<Pokemon>();
	    
	    private static int rondasGanadasJugadorUno, rondasGanadasJugadorDos;
	    
	    public static List<Pokemon> repartirCartasJugadorUno() { //otorga una lista de 7 cartas pokemon random
	        Random random = new Random();
	        
	        for (int i = 0; i < 7; i++) {
	            String nombreRandom = POKENOMBRES[(int) (Math.random() * POKENOMBRES.length)];   
	            if(Arrays.asList(NOMBRES_POKEMON_AGUA).contains(nombreRandom) ){
	            	PokemonAgua pokemonDeAguaRandom = new PokemonAgua(nombreRandom);
                    pokemonListJugadorUno.add(pokemonDeAguaRandom);
	            }else {
	            	if(Arrays.asList(NOMBRES_POKEMON_FUEGO).contains(nombreRandom) ){
	            	PokemonFuego pokemonDeFuegoRandom = new PokemonFuego(nombreRandom);
                    pokemonListJugadorUno.add(pokemonDeFuegoRandom);
	            	}else {
		            	if(Arrays.asList(NOMBRES_POKEMON_ELECTRICOS).contains(nombreRandom) ){
		            	PokemonElectrico pokemonDeElectricidadRandom = new PokemonElectrico(nombreRandom);
	                    pokemonListJugadorUno.add(pokemonDeElectricidadRandom);
		            	}else {
			            	if(Arrays.asList(NOMBRES_POKEMON_PLANTA).contains(nombreRandom) ){
			            	PokemonPlanta pokemonDePlantaRandom = new PokemonPlanta(nombreRandom);
		                    pokemonListJugadorUno.add(pokemonDePlantaRandom);
			            	}
		            	} 
	            	}
	            }
	        }            
	        return pokemonListJugadorUno;                          
	    }      
	    
	    public static List<Pokemon> repartirCartasJugadorDos() { //otorga una lista de 7 cartas pokemon random
	        Random random = new Random();
	        List<Pokemon> pokemonList = new ArrayList<Pokemon>();
	        for (int i = 0; i < 7; i++) {
	            String nombreRandom = POKENOMBRES[(int) (Math.random() * POKENOMBRES.length)];   
	            if(Arrays.asList(NOMBRES_POKEMON_AGUA).contains(nombreRandom) ){
	            	PokemonAgua pokemonDeAguaRandom = new PokemonAgua(nombreRandom);
                    pokemonListJugadorDos.add(pokemonDeAguaRandom);
	            }else {
	            	if(Arrays.asList(NOMBRES_POKEMON_FUEGO).contains(nombreRandom) ){
	            	PokemonFuego pokemonDeFuegoRandom = new PokemonFuego(nombreRandom);
                    pokemonListJugadorDos.add(pokemonDeFuegoRandom);
	            	}else {
		            	if(Arrays.asList(NOMBRES_POKEMON_ELECTRICOS).contains(nombreRandom) ){
		            	PokemonElectrico pokemonDeElectricidadRandom = new PokemonElectrico(nombreRandom);
	                    pokemonListJugadorDos.add(pokemonDeElectricidadRandom);
		            	}else {
			            	if(Arrays.asList(NOMBRES_POKEMON_PLANTA).contains(nombreRandom) ){
			            	PokemonPlanta pokemonDePlantaRandom = new PokemonPlanta(nombreRandom);
		                    pokemonListJugadorDos.add(pokemonDePlantaRandom);
			            	}
		            	}
	            	}
	            }

	        }               
	        return pokemonListJugadorDos;                
	    }
	        
	    public void compararCartas() { //Aca hace la comparacion de las 7 cartas y va restandole los puntos de vida al pokemon mas debil, los cuales son los mismos que el poder de ataque del pokemon ganador
	    	for (int i = 0; i < pokemonListJugadorUno.size(); i++) {
	    		Pokemon pokemonUno = pokemonListJugadorUno.get(i);
	    		Pokemon pokemonDos = pokemonListJugadorDos.get(i);
	    		
	    		
	    		if (pokemonUno.getAtaqueGolpe() > pokemonDos.getAtaqueGolpe()) {
	    			int diferencia = pokemonUno.getAtaqueGolpe() - pokemonDos.getAtaqueGolpe();
		            pokemonDos.restarVida(diferencia);
		        } else if (pokemonDos.getAtaqueGolpe() > pokemonUno.getAtaqueGolpe()) {
		        	int diferencia = pokemonDos.getAtaqueGolpe() - pokemonUno.getAtaqueGolpe();
		        	pokemonUno.restarVida(diferencia);
		        }
	    	}
		}
	    
	    
}    
	    
	            
	                       