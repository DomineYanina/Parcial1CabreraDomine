package ar.edu.unlam.pb2.pokeParcial;

public class PokemonPlanta extends Pokemon{ //faltan metodos de ataques

	private Integer puntosDeVidaAgua = 100;
	private Integer ataqueHojasCuchillas = -50;
	private Integer ataqueLatigoCepa = -30;
	private Integer debilidadPorTipologia = -50;
	
	public PokemonPlanta(String nombre) {
		super(nombre);
		
	}

	
}
