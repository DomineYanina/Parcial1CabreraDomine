package ar.edu.unlam.pb2.pokeParcial;

public class PokemonFuego extends Pokemon{ //faltan metodos de ataques

	private Integer puntosDeVidaAgua = 200;
	private Integer ataqueLanzallamas = -50;
	private Integer ataqueColmilloDeFuego = -30;
	private Integer debilidadPorTipologia = -50;

	public PokemonFuego(String nombre) {
		super(nombre);
		
	}

}
