package ar.edu.unlam.pb2.pokeParcial;

public class PokemonElectrico extends Pokemon{

	private Integer puntosDeVidaAgua = 150;
	private Integer ataqueTrueno = -50;
	private Integer ataqueChispazo = -30;
	private Integer debilidadPorTipologia = -50;

	public PokemonElectrico(String nombre) {
		super(nombre);
		
	}
	
}
